# 以下部分均为可更改部分

from answer_task1 import *


def init_idle_motion(ctrler):
    init_pos_xz = np.array([0, 0])
    init_facing_xz = np.array([0, 1])
    idle_loop_motion = build_loop_motion(
        BVHMotion('motion_material/idle.bvh'))
    idle_loop_motion = idle_loop_motion.translation_and_rotation(
        0, init_pos_xz, init_facing_xz)
    idle_loop_motion.joint_position[-1, 0, [0, 2]] = np.array([0, 0])
    cur_pos_xz = ctrler.current_desired_position[[0, 2]]
    cur_facing_xz = R.from_quat(ctrler.current_desired_rotation).apply(
        np.array([0, 0, 1])).flatten()[[0, 2]]
    idle_loop_motion = idle_loop_motion.translation_and_rotation(
        0, cur_pos_xz, cur_facing_xz)
    return idle_loop_motion.raw_copy()


def init_walk_motion(ctrler):
    init_pos_xz = np.array([0, 0])
    init_facing_xz = np.array([0, 1])
    walk_loop_motion = build_loop_motion(
        BVHMotion('motion_material/walk_forward.bvh'))
    walk_loop_motion = walk_loop_motion.translation_and_rotation(
        0, init_pos_xz, init_facing_xz)
    walk_loop_motion.joint_position[-1, 0, 0] = 0.
    cur_pos_xz = ctrler.current_desired_position[[0, 2]]
    cur_facing_xz = R.from_quat(ctrler.current_desired_rotation).apply(
        np.array([0, 0, 1])).flatten()[[0, 2]]
    walk_loop_motion = walk_loop_motion.translation_and_rotation(
        0, cur_pos_xz, cur_facing_xz)
    return walk_loop_motion.raw_copy()


def align_motion_with_desire(desire_pos, desire_rot, motion):
    res = motion.raw_copy()
    cur_pos_xz = desire_pos[[0, 2]]
    cur_facing_xz = R.from_quat(desire_rot).apply(
        np.array([0, 0, 1])).flatten()[[0, 2]]
    res = res.translation_and_rotation(
        0, cur_pos_xz, cur_facing_xz)
    return res

def local_motion(motion: BVHMotion):
    res = motion.raw_copy()
    res.joint_position[:, 0, [0, 2]] = np.array([0, 0])
    return res


class CharacterController():
    def __init__(self, controller) -> None:
        self.motions = []
        self.controller = controller
        self.cur_root_pos = self.controller.current_desired_position
        self.cur_root_rot = self.controller.current_desired_rotation
        idle_loop_motion = init_idle_motion(self.controller)
        self.idle_motion = idle_loop_motion
        idle_loop_motion_local = local_motion(self.idle_motion)
        self.idle_motion_local = idle_loop_motion_local
        walk_loop_motion = init_walk_motion(self.controller)
        self.walk_motion = walk_loop_motion
        walk_loop_motion_local = local_motion(self.walk_motion)
        self.walk_motion_local = walk_loop_motion_local
        self.motion_length = 0
        # one_loop_motion = idle_loop_motion
        one_loop_motion = walk_loop_motion_local
        while self.motion_length < 100:
            self.motions.append(one_loop_motion)
            self.motion_length += one_loop_motion.motion_length
            end_pos_xz = one_loop_motion.joint_position[-1, 0, [0, 2]]
            end_facing_xz = R.from_quat(one_loop_motion.joint_rotation[-1, 0]).apply(
                np.array([0, 0, 1])).flatten()[[0, 2]]
            idle_loop_motion = one_loop_motion.translation_and_rotation(
                0, end_pos_xz, end_facing_xz)
        self.cur_frame = 0
        self.next_motion = self.idle_motion
        self.blend_key_frame = -1
        self.state = "idle"
        self.last_desired_pos = self.cur_root_pos
        self.last_desired_rot = self.cur_root_rot
        pass

    def update_state(self,
                     desired_pos_list,
                     desired_rot_list,
                     desired_vel_list,
                     desired_avel_list,
                     current_gait
                     ):
        '''
        此接口会被用于获取新的期望状态
        Input: 平滑过的手柄输入,包含了现在(第0帧)和未来20,40,60,80,100帧的期望状态,以及一个额外输入的步态
        简单起见你可以先忽略步态输入,它是用来控制走路还是跑步的
            desired_pos_list: 期望位置, 6x3的矩阵, 每一行对应0，20，40...帧的期望位置(水平)， 期望位置可以用来拟合根节点位置也可以是质心位置或其他
            desired_rot_list: 期望旋转, 6x4的矩阵, 每一行对应0，20，40...帧的期望旋转(水平), 期望旋转可以用来拟合根节点旋转也可以是其他
            desired_vel_list: 期望速度, 6x3的矩阵, 每一行对应0，20，40...帧的期望速度(水平), 期望速度可以用来拟合根节点速度也可以是其他
            desired_avel_list: 期望角速度, 6x3的矩阵, 每一行对应0，20，40...帧的期望角速度(水平), 期望角速度可以用来拟合根节点角速度也可以是其他

        Output: 同作业一,输出下一帧的关节名字,关节位置,关节旋转
            joint_name: List[str], 代表了所有关节的名字
            joint_translation: np.ndarray，形状为(M, 3)的numpy数组，包含着所有关节的全局位置
            joint_orientation: np.ndarray，形状为(M, 4)的numpy数组，包含着所有关节的全局旋转(四元数)
        Tips:
            输出三者顺序需要对应
            controller 本身有一个move_speed属性,是形状(3,)的ndarray,
            分别对应着面朝向移动速度,侧向移动速度和向后移动速度.目前根据LAFAN的统计数据设为(1.75,1.5,1.25)
            如果和你的角色动作速度对不上,你可以在init或这里对属性进行修改
        '''
        return self.update_state_2(desired_pos_list,
                            desired_rot_list,
                            desired_vel_list,
                            desired_avel_list,
                            current_gait)
        # 一个简单的例子，输出第i帧的状态
        joint_name = self.motions[0].joint_name
        joint_translation, joint_orientation = self.motions[0].batch_forward_kinematics(
        )
        joint_translation = joint_translation[self.cur_frame]
        joint_orientation = joint_orientation[self.cur_frame]

        self.cur_root_pos = joint_translation[0]
        self.cur_root_rot = joint_orientation[0]
        cur_motion_length = self.motions[0].motion_length
        self.cur_frame += 1
        self.motion_length -= 1
        while self.motion_length < 100:
            # print("motion_length: %f,add new motion" % self.motion_length)
            end_pos_xz = self.motions[-1].joint_position[-1, 0, [0, 2]]
            end_facing_xz = R.from_quat(self.motions[-1].joint_rotation[-1, 0]).apply(
                np.array([0, 0, 1])).flatten()[[0, 2]]
            new_motion = self.next_motion.raw_copy()
            # print("old pos: ", new_motion.joint_position[0, 0, [0, 2]])
            # print("target pos: ", end_pos_xz)
            new_motion = new_motion.translation_and_rotation(
                0, end_pos_xz, end_facing_xz)
            # print("new pos: ", new_motion.joint_position[0, 0, [0, 2]])
            self.motions.append(new_motion)
            self.motion_length += new_motion.motion_length
        if self.cur_frame == cur_motion_length:
            self.motions.pop(0)
        desired_pos = desired_pos_list[-1]
        desired_rot = desired_rot_list[-1]
        self.cur_frame = self.cur_frame % cur_motion_length
        cur_motion_length = self.motions[0].motion_length
        dist = np.linalg.norm(desired_pos - self.last_desired_pos)
        rot_dist = np.linalg.norm(desired_rot - self.last_desired_rot)
        # if rot_dist > 0.3:
        #     print(rot_dist)
        if dist > 0.1:
            print("dist: ", dist)
            if self.state == "idle":
                self.state = "walk"
                # print("old pos: ", new_motion.joint_position[0, 0, [0, 2]])
                # print("target pos: ", end_pos_xz)
                self.next_motion = self.walk_motion
                new_motion = align_motion_with_desire(
                    self.cur_root_pos, desired_rot, self.next_motion)
                # new_motions = [
                #     self.idle_motion,  # turn to the desired facing
                #     self.walk_motion   # start walking
                # ]
                fourty_minus_frame = 100 - (cur_motion_length - self.cur_frame)
                blend_motion = None
                if fourty_minus_frame > 0:
                    blend_motion = self.motions[0].sub_sequence(
                        self.cur_frame, cur_motion_length)
                    blend_motion.append(
                        self.motions[1].sub_sequence(0, fourty_minus_frame))
                else:
                    blend_motion = self.motions[0].sub_sequence(
                        self.cur_frame, fourty_minus_frame)
                print("motion length: ", blend_motion.motion_length)
                blend_motion = concatenate_two_motions(
                    blend_motion, new_motion, 100, 100)
                blend_motion = align_motion_with_desire(
                    self.cur_root_pos, self.cur_root_rot, blend_motion)
                self.motions = [blend_motion]
                self.motion_length = blend_motion.motion_length
                self.cur_frame = 0
            elif self.state == "walk":
                if rot_dist < 0.3:
                    self.state = "idle"
                    self.next_motion = align_motion_with_desire(
                        desired_pos, desired_rot, self.idle_motion)
                    fourty_minus_frame = 100 - (cur_motion_length - self.cur_frame)
                    blend_motion = None
                    if fourty_minus_frame > 0:
                        blend_motion = self.motions[0].sub_sequence(
                            self.cur_frame, cur_motion_length)
                        blend_motion.append(
                            self.motions[1].sub_sequence(0, fourty_minus_frame))
                    else:
                        blend_motion = self.motions[0].sub_sequence(
                            self.cur_frame, fourty_minus_frame)
                    print("motion length: ", blend_motion.motion_length)
                    blend_motion = concatenate_two_motions(
                        blend_motion, self.next_motion, 100, 100)
                    blend_motion = align_motion_with_desire(
                        self.cur_root_pos, desired_rot, blend_motion)
                    self.motions = [blend_motion]
                    self.motion_length = blend_motion.motion_length
                    self.cur_frame = 0
                else:
                    self.state = "walk"
                    self.next_motion = self.walk_motion
                    new_motion = align_motion_with_desire(
                        self.cur_root_pos, desired_rot, self.next_motion)
                    fourty_minus_frame = 100 - (cur_motion_length - self.cur_frame)
                    blend_motion = None
                    if fourty_minus_frame > 0:
                        blend_motion = self.motions[0].sub_sequence(
                            self.cur_frame, cur_motion_length)
                        blend_motion.append(
                            self.motions[1].sub_sequence(0, fourty_minus_frame))
                    else:
                        blend_motion = self.motions[0].sub_sequence(
                            self.cur_frame, fourty_minus_frame)
                    print("motion length: ", blend_motion.motion_length)
                    blend_motion = concatenate_two_motions(
                        blend_motion, new_motion, 100, 100)
                    blend_motion = align_motion_with_desire(
                        self.cur_root_pos, self.cur_root_rot, blend_motion)
                    self.motions = [blend_motion]
                    self.motion_length = blend_motion.motion_length
                    self.cur_frame = 0

        self.last_desired_pos = desired_pos
        self.last_desired_rot = desired_rot

        return joint_name, joint_translation, joint_orientation
    
    def update_state_2(self,
                       desired_pos_list,
                       desired_rot_list,
                       desired_vel_list,
                       desired_avel_list,
                       current_gait):
        # 一个简单的例子，输出第i帧的状态
        joint_name = self.motions[0].joint_name
        joint_translation, joint_orientation = self.motions[0].batch_forward_kinematics(
        )
        joint_translation = joint_translation[self.cur_frame]
        joint_orientation = joint_orientation[self.cur_frame]

        self.cur_root_pos = joint_translation[0]
        self.cur_root_rot = joint_orientation[0]
        cur_motion_length = self.motions[0].motion_length
        self.cur_frame += 1
        self.motion_length -= 1
        self.next_motion = self.walk_motion_local
        while self.motion_length < 100:
            # print("motion_length: %f,add new motion" % self.motion_length)
            end_pos_xz = self.motions[-1].joint_position[-1, 0, [0, 2]]
            end_facing_xz = R.from_quat(self.motions[-1].joint_rotation[-1, 0]).apply(
                np.array([0, 0, 1])).flatten()[[0, 2]]
            new_motion = self.next_motion.raw_copy()
            # print("old pos: ", new_motion.joint_position[0, 0, [0, 2]])
            # print("target pos: ", end_pos_xz)
            new_motion = new_motion.translation_and_rotation(
                0, end_pos_xz, end_facing_xz)
            # print("new pos: ", new_motion.joint_position[0, 0, [0, 2]])
            self.motions.append(new_motion)
            self.motion_length += new_motion.motion_length
        if self.cur_frame == cur_motion_length:
            self.motions.pop(0)
        self.cur_frame = self.cur_frame % cur_motion_length
            
        return joint_name, joint_translation, joint_orientation

    def sync_controller_and_character(self, controller, character_state):
        '''
        这一部分用于同步你的角色和手柄的状态
        更新后很有可能会出现手柄和角色的位置不一致，这里可以用于修正
        让手柄位置服从你的角色? 让角色位置服从手柄? 或者插值折中一下?
        需要你进行取舍
        Input: 手柄对象，角色状态
        手柄对象我们提供了set_pos和set_rot接口,输入分别是3维向量和四元数,会提取水平分量来设置手柄的位置和旋转
        角色状态实际上是一个tuple, (joint_name, joint_translation, joint_orientation),为你在update_state中返回的三个值
        你可以更新他们,并返回一个新的角色状态
        '''

        # 一个简单的例子，将手柄的位置与角色对齐
        controller.set_pos(self.cur_root_pos)
        controller.set_rot(self.cur_root_rot)

        return character_state
    # 你的其他代码,state matchine, motion matching, learning, etc.
